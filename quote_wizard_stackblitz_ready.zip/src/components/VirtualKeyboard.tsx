import React, { useState } from 'react';
import { Button } from '@/components/ui/button';

interface VirtualKeyboardProps {
  onKeyPress: (key: string) => void;
  onBackspace: () => void;
  onClose: () => void;
  onTab?: () => void;
}

const VirtualKeyboard: React.FC<VirtualKeyboardProps> = ({ onKeyPress, onBackspace, onClose, onTab }) => {
  const [isShift, setIsShift] = useState(false);
  const [capsLock, setCapsLock] = useState(false);
  const [showNumbers, setShowNumbers] = useState(false);

  const letterRows = [
    ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
    ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'],
    ['z', 'x', 'c', 'v', 'b', 'n', 'm']
  ];

  const numberRows = [
    ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
    ['-', '/', ':', ';', '(', ')', '$', '&', '@', '"'],
    ['.', ',', '?', '!', "'", '"', '[', ']', '{', '}']
  ];

  const getCurrentRows = () => {
    if (showNumbers) return numberRows;
    const rows = letterRows.map(row => 
      row.map(key => {
        if (isShift || capsLock) {
          return key.toUpperCase();
        }
        return key;
      })
    );
    return rows;
  };

  const handleKeyPress = (key: string) => {
    onKeyPress(key);
    if (isShift && !capsLock) {
      setIsShift(false);
    }
  };

  const handleShift = () => {
    setIsShift(!isShift);
  };

  const toggleNumbers = () => {
    setShowNumbers(!showNumbers);
  };

  const rows = getCurrentRows();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end z-50">
      <div className="w-full bg-gray-100 p-1 rounded-t-lg max-w-md mx-auto">
        <div className="flex justify-between items-center mb-1">
          <span className="text-xs font-semibold">Keyboard</span>
          <Button onClick={onClose} variant="outline" size="sm" className="h-6 px-2 text-xs">Done</Button>
        </div>
        
        <div className="space-y-0.5">
          {/* First row with numbers or symbols */}
          {!showNumbers && (
            <div className="flex justify-center gap-0.5">
              {(isShift ? ['!', '@', '#', '$', '%', '^', '&', '*', '(', ')'] : ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0']).map((key) => (
                <Button key={key} onClick={() => handleKeyPress(key)} variant="outline" className="h-7 min-w-6 text-xs p-0">{key}</Button>
              ))}
            </div>
          )}
          
          {/* Main letter/number rows */}
          {rows.map((row, rowIndex) => (
            <div key={rowIndex} className="flex justify-center gap-0.5">
              {row.map((key) => (
                <Button key={key} onClick={() => handleKeyPress(key)} variant="outline" className="h-7 min-w-6 text-xs p-0">{key}</Button>
              ))}
            </div>
          ))}
          
          {/* Bottom row with special keys */}
          <div className="flex justify-center gap-0.5">
            <Button onClick={toggleNumbers} variant="outline" className="h-7 px-2 text-xs">
              {showNumbers ? 'ABC' : '123'}
            </Button>
            {!showNumbers && (
              <Button onClick={handleShift} variant={isShift ? "default" : "outline"} className="h-7 px-2 text-xs">⇧</Button>
            )}
            <Button onClick={() => handleKeyPress(' ')} variant="outline" className="h-7 flex-1 text-xs">space</Button>
            <Button onClick={() => handleKeyPress('.')} variant="outline" className="h-7 px-2 text-xs">.</Button>
            {onTab && (
              <Button onClick={onTab} variant="outline" className="h-7 px-2 text-xs">tab</Button>
            )}
            <Button onClick={onBackspace} variant="outline" className="h-7 px-2 text-xs">⌫</Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VirtualKeyboard;
import React from 'react';
import { useQuote } from '@/contexts/QuoteContext';

const QuoteDetails: React.FC = () => {
  const { quoteData } = useQuote();

  const getDetailsList = () => {
    const details: string[] = [];
    
    // Split System Heat Pump Details
    if (quoteData.systemSubType === 'Split System Heat Pump') {
      if (quoteData.tonnage) {
        const tonnageLabels: { [key: string]: string } = {
          '2-ton': '2 Ton (800-1200 sq.ft.)',
          '2.5-ton': '2.5 Ton (1200-1500 sq.ft.)',
          '3-ton': '3 Ton (1500-1800 sq.ft.)',
          '3.5-ton': '3.5 Ton (1800-2100 sq.ft.)',
          '4-ton': '4 Ton (2100-2400 sq.ft.)',
          '5-ton': '5 Ton (2400-3000 sq.ft.)'
        };
        details.push(`Tonnage: ${tonnageLabels[quoteData.tonnage] || quoteData.tonnage}`);
      }
      if (quoteData.airHandlerLocation) {
        const locationLabels: { [key: string]: string } = {
          'garage-stand': 'In Garage on Stand',
          'garage-ceiling': 'Garage Ceiling',
          'attic': 'Attic',
          'laundry': 'Laundry Room',
          'closet': 'Closet',
          'other': 'Other'
        };
        details.push(`Air Handler Location: ${locationLabels[quoteData.airHandlerLocation] || quoteData.airHandlerLocation}`);
      }
      if (quoteData.standReplaced) {
        details.push(`Stand Replaced: ${quoteData.standReplaced}`);
      }
    }
    
    // Gas Furnace Details (Heating Only)
    if (quoteData.systemSubType === 'Gas Furnace') {
      // Home Size - convert from ID to sq ft range
      if (quoteData.homeSize) {
        const homeSizeLabels: { [key: string]: string } = {
          'basic': '800-1200 sq.ft.',
          'standard': '1200-1500 sq. ft.',
          'premium': '1500-1800 sq. ft.',
          'deluxe': '1800-2100 sq. ft.',
          'custom': '2100-2400 sq. ft.',
          'emergency': '2400-3000 sq.ft.'
        };
        details.push(`Home Size: ${homeSizeLabels[quoteData.homeSize] || quoteData.homeSize}`);
      }
      
      // Furnace Efficiency
      if (quoteData.furnaceEfficiency) {
        const efficiencyLabels: { [key: string]: string } = {
          '80': '80%',
          '90': '90%+'
        };
        details.push(`Furnace Efficiency: ${efficiencyLabels[quoteData.furnaceEfficiency] || quoteData.furnaceEfficiency}`);
      }
      
      // Gas Type
      if (quoteData.gasType) {
        const gasTypeLabels: { [key: string]: string } = {
          'natural': 'Natural Gas',
          'lp': 'LP Gas'
        };
        details.push(`Type of Gas Used: ${gasTypeLabels[quoteData.gasType] || quoteData.gasType}`);
      }
      
      // Furnace Stand Rebuilt
      if (quoteData.furnaceStandRebuilt) {
        details.push(`Furnace Stand Rebuilt: ${quoteData.furnaceStandRebuilt === 'yes' ? 'Yes' : 'No'}`);
      }
    }
    
    // Gas Furnace System Details (Heating & Cooling)
    if (quoteData.systemSubType === 'Gas Furnace System') {
      // Home Size from systemDetails (cooling unit size)
      if (quoteData.systemDetails) {
        const sizeLabels: { [key: string]: string } = {
          '2-ton': '2 Ton (800-1200 sq.ft.)',
          '2.5-ton': '2.5 Ton (1200-1500 sq.ft.)',
          '3-ton': '3 Ton (1500-1800 sq.ft.)',
          '3.5-ton': '3.5 Ton (1800-2100 sq.ft.)',
          '4-ton': '4 Ton (2100-2400 sq.ft.)',
          '5-ton': '5 Ton (2400-3000 sq.ft.)'
        };
        details.push(`Cooling Unit Size: ${sizeLabels[quoteData.systemDetails] || quoteData.systemDetails}`);
      }
      
      // Furnace Efficiency
      if (quoteData.furnaceEfficiency) {
        const efficiencyLabels: { [key: string]: string } = {
          '80%': '80%',
          '90%': '90%+'
        };
        details.push(`Furnace Efficiency: ${efficiencyLabels[quoteData.furnaceEfficiency] || quoteData.furnaceEfficiency}`);
      }
      
      // Gas Type
      if (quoteData.gasType) {
        details.push(`Type of Gas Used: ${quoteData.gasType}`);
      }
      
      if (quoteData.standRebuilt) {
        details.push(`Stand Rebuilt: ${quoteData.standRebuilt}`);
      }
    }
    
    // Ductless Mini-Split Details
    if (quoteData.systemSubType === 'Ductless Mini-Split') {
      if (quoteData.systemDetails) {
        details.push(`Unit Size: ${quoteData.systemDetails}`);
      }
      if (quoteData.systemSubDetails) {
        details.push(`Zones: ${quoteData.systemSubDetails}`);
      }
    }
    
    // Package Unit Details (Heating & Cooling)
    if (quoteData.systemSubType === 'Package Unit') {
      if (quoteData.packageUnitLabel && quoteData.packageUnitSubLabel) {
        details.push(`Package Unit: ${quoteData.packageUnitLabel} (${quoteData.packageUnitSubLabel})`);
      }
      if (quoteData.furnaceStandRebuilt) {
        details.push(`Furnace Stand Rebuilt: ${quoteData.furnaceStandRebuilt === 'yes' ? 'Yes' : 'No'}`);
      }
    }
    
    return details;
  };

  const detailsList = getDetailsList();

  if (detailsList.length === 0) {
    return <span className="font-medium truncate ml-2">No details available</span>;
  }

  return (
    <div className="font-medium ml-2 space-y-1">
      {detailsList.map((detail, index) => (
        <div key={index} className="text-xs sm:text-sm break-words">
          {detail}
        </div>
      ))}
    </div>
  );
};

export default QuoteDetails;
import React from 'react';
import { useQuote } from '@/contexts/QuoteContext';

const StepIndicator: React.FC = () => {
  const { currentStep } = useQuote();
  
  const steps = [
    { number: 1, title: 'System Type' },
    { number: 2, title: 'System Details' },
    { number: 3, title: 'Customer Information' },
    { number: 4, title: 'Quote' }
  ];

  // Determine completed steps based on current step
  const getStepStatus = (stepNumber: number) => {
    // Step 1 is completed if we're on step 2 or beyond
    if (stepNumber === 1) {
      return currentStep >= 2 || currentStep === '2a' || currentStep === '2d' || currentStep === 'furnace-efficiency' || currentStep === 'gas-type';
    }
    // Step 2 is completed if we're on step 3 or beyond (including gas furnace sub-steps)
    if (stepNumber === 2) {
      return currentStep >= 3 || currentStep === 'furnace-efficiency' || currentStep === 'gas-type';
    }
    // Step 3 is completed if we're on step 4 OR if we're currently on step 3
    if (stepNumber === 3) {
      return currentStep >= 3;
    }
    // Step 4 is completed if we're on step 4
    if (stepNumber === 4) {
      return currentStep === 4;
    }
    return false;
  };

  const getConnectorStatus = (stepNumber: number) => {
    // Connector after step 1 is green if step 2 is completed
    if (stepNumber === 1) {
      return currentStep >= 3 || currentStep === 'furnace-efficiency' || currentStep === 'gas-type';
    }
    // Connector after step 2 is green if step 3 is completed
    if (stepNumber === 2) {
      return currentStep >= 3;
    }
    // Connector after step 3 is green if step 4 is active
    if (stepNumber === 3) {
      return currentStep === 4;
    }
    return false;
  };

  return (
    <div className="flex justify-center mb-6 px-2">
      <div className="flex items-center space-x-2 max-w-full overflow-x-auto">
        {steps.map((step, index) => (
          <React.Fragment key={step.number}>
            <div className="flex flex-col items-center min-w-0 flex-shrink-0">
              <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium ${
                getStepStatus(step.number)
                  ? 'bg-green-600 text-white'
                  : 'bg-gray-300 text-gray-600'
              }`}>
                {step.number}
              </div>
              <span className="text-xs mt-1 text-gray-600 text-center max-w-16 truncate">{step.title}</span>
            </div>
            {index < steps.length - 1 && (
              <div className={`w-8 h-0.5 flex-shrink-0 ${
                getConnectorStatus(step.number)
                  ? 'bg-green-600' : 'bg-gray-300'
              }`} />
            )}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
};

export default StepIndicator;
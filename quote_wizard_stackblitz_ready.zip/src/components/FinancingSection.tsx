import React from 'react';

export const FinancingSection: React.FC = () => {
  return (
    <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
      <div className="flex items-start gap-4">
        <div className="flex-shrink-0">
          <img 
            src="https://d64gsuwffb70l.cloudfront.net/682fec4a23651177574ccb93_1748038672420_20095e4e.jpg" 
            alt="Financing Representative"
            className="w-20 h-20 sm:w-24 sm:h-24 object-cover rounded-full"
          />
        </div>
        <div className="flex-1">
          <div className="relative bg-white p-3 rounded-lg shadow-sm border border-gray-200">
            <div className="absolute -left-2 top-4 w-0 h-0 border-t-8 border-t-transparent border-r-8 border-r-white border-b-8 border-b-transparent"></div>
            <p className="text-sm sm:text-base text-gray-800 leading-relaxed">
              Your Comfort, Your Way – Get Your Quote and Explore Flexible Financing Options for <em>Any</em> Credit Situation!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FinancingSection;
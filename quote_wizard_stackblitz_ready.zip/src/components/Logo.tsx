import React from 'react';

const Logo: React.FC = () => {
  return (
    <div className="flex justify-center mb-4 sm:mb-6 px-2">
      <img 
        src="https://d64gsuwffb70l.cloudfront.net/682fec4a23651177574ccb93_1747971849490_889e918e.png" 
        alt="Dynamic Air-Care Logo" 
        className="h-12 sm:h-16 w-auto object-contain max-w-full"
      />
    </div>
  );
};

export default Logo;
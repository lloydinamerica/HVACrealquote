import React from 'react';
import { Button } from '@/components/ui/button';

interface FrontPageProps {
  onBegin: () => void;
}

const FrontPage: React.FC<FrontPageProps> = ({ onBegin }) => {
  return (
    <div className="min-h-screen bg-white overflow-x-hidden flex flex-col">
      <div className="w-full max-w-screen-xl mx-auto px-2 sm:px-4 py-8 sm:py-12 flex-1 flex flex-col justify-between">
        <div className="w-full text-center space-y-16">
          {/* Main Title */}
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-800">
            Get an Instant AC Quote Now!
          </h1>
          
          {/* First Image - HVAC Systems (narrower) */}
          <div>
            <img 
              src="https://d64gsuwffb70l.cloudfront.net/682fec4a23651177574ccb93_1748019846565_7375dbc6.png" 
              alt="HVAC Systems" 
              className="w-full max-w-lg mx-auto h-auto rounded-lg shadow-lg"
            />
          </div>
          
          {/* Subheading (narrower text) */}
          <div className="max-w-2xl mx-auto">
            <h2 className="text-lg sm:text-xl md:text-2xl font-semibold text-gray-700">
              Just browsing or ready to buy? We make it easy to take the next step.
            </h2>
          </div>
          
          {/* Second Image - Logo (smaller) */}
          <div>
            <img 
              src="https://d64gsuwffb70l.cloudfront.net/682fec4a23651177574ccb93_1748020193117_d372dcb6.png" 
              alt="Dynamic Air-Care Logo" 
              className="w-full max-w-xs mx-auto h-auto"
            />
          </div>
        </div>
        
        {/* Begin Button - pushed to bottom */}
        <div className="text-center mt-16 pb-8">
          <Button 
            onClick={onBegin}
            className="bg-green-800 hover:bg-green-900 text-white text-lg px-8 py-3 rounded-lg font-semibold"
            size="lg"
          >
            Begin
          </Button>
        </div>
      </div>
    </div>
  );
};

export default FrontPage;
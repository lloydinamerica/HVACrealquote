import React, { useState } from 'react';
import { useQuote } from '@/contexts/QuoteContext';
import Logo from './Logo';
import StepIndicator from './StepIndicator';
import StepOne from './steps/StepOne';
import StepTwo from './steps/StepTwo';
import StepTwoA from './steps/StepTwoA';
import StepTwoD from './steps/StepTwoD';
import StepThree from './steps/StepThree';
import StepFour from './steps/StepFour';
import GasFurnaceSize from './steps/GasFurnaceSize';
import FurnaceEfficiency from './steps/FurnaceEfficiency';
import GasType from './steps/GasType';
import FrontPage from './FrontPage';

const QuoteApp: React.FC = () => {
  const { currentStep } = useQuote();
  const [showFrontPage, setShowFrontPage] = useState(true);

  const handleBegin = () => {
    setShowFrontPage(false);
  };

  if (showFrontPage) {
    return <FrontPage onBegin={handleBegin} />;
  }

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 1:
        return <StepOne />;
      case 2:
        return <StepTwo />;
      case '2a':
        return <StepTwoA />;
      case '2d':
        return <StepTwoD />;
      case 'gas-furnace-size':
        return <GasFurnaceSize />;
      case 'furnace-efficiency':
        return <FurnaceEfficiency />;
      case 'gas-type':
        return <GasType />;
      case 3:
        return <StepThree />;
      case 4:
        return <StepFour />;
      default:
        return <StepOne />;
    }
  };

  return (
    <div className="min-h-screen bg-white overflow-x-hidden">
      <div className="w-full max-w-screen-xl mx-auto px-2 sm:px-4 py-4 sm:py-8">
        <div className="w-full">
          <Logo />
          <StepIndicator />
          <div className="w-full">
            {renderCurrentStep()}
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuoteApp;
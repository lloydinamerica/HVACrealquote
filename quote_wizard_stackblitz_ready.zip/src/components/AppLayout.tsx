import React from 'react';
import { QuoteProvider } from '@/contexts/QuoteContext';
import QuoteApp from './QuoteApp';

const AppLayout: React.FC = () => {
  return (
    <QuoteProvider>
      <QuoteApp />
    </QuoteProvider>
  );
};

export default AppLayout;
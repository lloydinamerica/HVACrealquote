import React, { useState, useRef } from 'react';
import { useQuote } from '@/contexts/QuoteContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import VirtualKeyboard from '@/components/VirtualKeyboard';
import { useIsMobile } from '@/hooks/use-mobile';

const StepThree: React.FC = () => {
  const { quoteData, updateQuoteData, setCurrentStep } = useQuote();
  const isMobile = useIsMobile();
  const [formData, setFormData] = useState({
    fullName: quoteData.fullName || '',
    email: quoteData.email || '',
    phone: quoteData.phone || '',
    address: quoteData.address || '',
    city: quoteData.city || '',
    zipCode: quoteData.zipCode || ''
  });
  const [showKeyboard, setShowKeyboard] = useState(false);
  const [activeField, setActiveField] = useState<string | null>(null);
  const inputRefs = useRef<{[key: string]: HTMLInputElement | null}>({});

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleInputFocus = (field: string) => {
    setActiveField(field);
    if (isMobile) {
      setShowKeyboard(true);
    }
  };

  const handleKeyPress = (key: string) => {
    if (activeField) {
      const currentValue = formData[activeField as keyof typeof formData];
      handleInputChange(activeField, currentValue + key);
    }
  };

  const handleBackspace = () => {
    if (activeField) {
      const currentValue = formData[activeField as keyof typeof formData];
      handleInputChange(activeField, currentValue.slice(0, -1));
    }
  };

  const handleTab = () => {
    const fields = ['fullName', 'email', 'phone', 'address', 'city', 'zipCode'];
    const currentIndex = fields.indexOf(activeField || '');
    const nextIndex = (currentIndex + 1) % fields.length;
    const nextField = fields[nextIndex];
    
    setActiveField(nextField);
    const nextInput = inputRefs.current[nextField];
    if (nextInput) {
      nextInput.focus();
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.fullName && formData.email && formData.phone) {
      updateQuoteData(formData);
      setCurrentStep(4);
    }
  };

  const isValid = formData.fullName && formData.email && formData.phone;

  return (
    <div className="w-full max-w-4xl mx-auto px-1 sm:px-2">
      <Card className="w-full">
        <CardHeader className="pb-2 sm:pb-4">
          <CardTitle className="text-center text-base sm:text-xl md:text-2xl px-1">
            Customer Information
          </CardTitle>
          <div className="text-xs sm:text-sm text-gray-600 text-center px-2 mt-2">
            All information gathered here is encrypted and is not shared with anyone, including most employees. The information is only used to compile an accurate quote that you can hold us to. Address is optional information but if collected allows us to more accurately evaluate the home for the quote.
          </div>
        </CardHeader>
        <CardContent className="px-2 sm:px-4">
          <form onSubmit={handleSubmit} className="space-y-3 sm:space-y-4">
            <div className="text-xs sm:text-sm font-medium text-gray-700 mb-3">
              * Required Information
            </div>
            
            <div className="space-y-3 sm:space-y-4">
              <div className="space-y-1 sm:space-y-2">
                <Label htmlFor="fullName" className="text-xs sm:text-sm">Full Name *</Label>
                <Input
                  ref={(el) => inputRefs.current.fullName = el}
                  id="fullName"
                  type="text"
                  value={formData.fullName}
                  onChange={(e) => handleInputChange('fullName', e.target.value)}
                  onFocus={() => handleInputFocus('fullName')}
                  placeholder="Enter your full name"
                  className="h-8 sm:h-10 md:h-12 text-xs sm:text-sm"
                  required
                  readOnly={isMobile}
                />
              </div>
              
              <div className="space-y-1 sm:space-y-2">
                <Label htmlFor="email" className="text-xs sm:text-sm">Email Address *</Label>
                <Input
                  ref={(el) => inputRefs.current.email = el}
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  onFocus={() => handleInputFocus('email')}
                  placeholder="Enter your email address"
                  className="h-8 sm:h-10 md:h-12 text-xs sm:text-sm"
                  required
                  readOnly={isMobile}
                />
              </div>
              
              <div className="space-y-1 sm:space-y-2">
                <Label htmlFor="phone" className="text-xs sm:text-sm">Phone Number *</Label>
                <Input
                  ref={(el) => inputRefs.current.phone = el}
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => handleInputChange('phone', e.target.value)}
                  onFocus={() => handleInputFocus('phone')}
                  placeholder="Enter your phone number"
                  className="h-8 sm:h-10 md:h-12 text-xs sm:text-sm"
                  required
                  readOnly={isMobile}
                />
              </div>
              
              <div className="space-y-1 sm:space-y-2">
                <Label htmlFor="address" className="text-xs sm:text-sm">Address (optional)</Label>
                <Input
                  ref={(el) => inputRefs.current.address = el}
                  id="address"
                  type="text"
                  value={formData.address}
                  onChange={(e) => handleInputChange('address', e.target.value)}
                  onFocus={() => handleInputFocus('address')}
                  placeholder="Enter your address"
                  className="h-8 sm:h-10 md:h-12 text-xs sm:text-sm"
                  readOnly={isMobile}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-2 sm:gap-4">
                <div className="space-y-1 sm:space-y-2">
                  <Label htmlFor="city" className="text-xs sm:text-sm">City</Label>
                  <Input
                    ref={(el) => inputRefs.current.city = el}
                    id="city"
                    type="text"
                    value={formData.city}
                    onChange={(e) => handleInputChange('city', e.target.value)}
                    onFocus={() => handleInputFocus('city')}
                    placeholder="City"
                    className="h-8 sm:h-10 md:h-12 text-xs sm:text-sm"
                    readOnly={isMobile}
                  />
                </div>
                
                <div className="space-y-1 sm:space-y-2">
                  <Label htmlFor="zipCode" className="text-xs sm:text-sm">Zip Code</Label>
                  <Input
                    ref={(el) => inputRefs.current.zipCode = el}
                    id="zipCode"
                    type="text"
                    value={formData.zipCode}
                    onChange={(e) => handleInputChange('zipCode', e.target.value)}
                    onFocus={() => handleInputFocus('zipCode')}
                    placeholder="Zip Code"
                    className="h-8 sm:h-10 md:h-12 text-xs sm:text-sm"
                    readOnly={isMobile}
                  />
                </div>
              </div>
            </div>
            
            <Button 
              type="submit" 
              className="w-full h-8 sm:h-10 md:h-12 text-xs sm:text-sm md:text-base mt-4 bg-green-500 hover:bg-green-600 text-white"
              disabled={!isValid}
            >
              Get Quote
            </Button>
          </form>
        </CardContent>
      </Card>
      
      {showKeyboard && isMobile && (
        <VirtualKeyboard
          onKeyPress={handleKeyPress}
          onBackspace={handleBackspace}
          onClose={() => setShowKeyboard(false)}
          onTab={handleTab}
        />
      )}
    </div>
  );
};

export default StepThree;
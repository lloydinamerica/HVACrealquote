import React from 'react';
import { useQuote } from '@/contexts/QuoteContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import QuoteDetails from '@/components/QuoteDetails';

const StepFour: React.FC = () => {
  const { quoteData, calculatePrice, setCurrentStep } = useQuote();
  const price = calculatePrice();
  
  const handleStartOver = () => {
    setCurrentStep(1);
  };

  const formatPrice = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatAddress = () => {
    const { address, city, zipCode } = quoteData;
    if (!address && !city && !zipCode) return null;
    
    const parts = [];
    if (address) parts.push(address);
    if (city) parts.push(city);
    if (zipCode) parts.push(zipCode);
    
    return parts.join(', ');
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-1 sm:px-2">
      <Card className="w-full">
        <CardHeader className="pb-2 sm:pb-4">
          <CardTitle className="text-center text-base sm:text-xl md:text-2xl text-green-600 px-1">
            Your Quote
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 sm:space-y-4 px-2 sm:px-4">
          <div className="bg-green-50 p-2 sm:p-4 rounded-lg border border-green-200">
            <div className="text-center">
              <h3 className="text-lg sm:text-2xl md:text-3xl font-bold text-green-700 mb-1 sm:mb-2">
                {formatPrice(price)}
              </h3>
              <p className="text-xs sm:text-sm text-green-600">Estimated Installation Cost</p>
            </div>
          </div>
          
          <Separator />
          
          <div className="space-y-2 sm:space-y-3">
            <h4 className="font-semibold text-xs sm:text-sm md:text-base">Quote Summary:</h4>
            <div className="space-y-1 sm:space-y-2 text-xs sm:text-sm">
              <div className="flex justify-between break-words">
                <span>System Type:</span>
                <span className="font-medium truncate ml-2">{quoteData.systemType}</span>
              </div>
              <div className="flex justify-between break-words">
                <span>Sub-Type:</span>
                <span className="font-medium truncate ml-2">{quoteData.systemSubType}</span>
              </div>
              <div className="break-words">
                <span>Details:</span>
                <QuoteDetails />
              </div>
            </div>
          </div>
          
          <Separator />
          
          <div className="space-y-2 sm:space-y-3">
            <h4 className="font-semibold text-xs sm:text-sm md:text-base">Contact Information:</h4>
            <div className="space-y-1 sm:space-y-2 text-xs sm:text-sm">
              <div className="flex justify-between break-words">
                <span>Name:</span>
                <span className="font-medium truncate ml-2">{quoteData.fullName}</span>
              </div>
              <div className="flex justify-between break-words">
                <span>Email:</span>
                <span className="font-medium truncate ml-2">{quoteData.email}</span>
              </div>
              <div className="flex justify-between break-words">
                <span>Phone:</span>
                <span className="font-medium truncate ml-2">{quoteData.phone}</span>
              </div>
              {formatAddress() && (
                <div className="flex justify-between break-words">
                  <span>Address:</span>
                  <span className="font-medium truncate ml-2">{formatAddress()}</span>
                </div>
              )}
            </div>
          </div>
          
          <div className="pt-2 sm:pt-4">
            <Button 
              onClick={handleStartOver}
              variant="outline"
              className="w-full h-8 sm:h-10 md:h-12 text-xs sm:text-sm"
            >
              Start New Quote
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StepFour;
import React from 'react';
import { useQuote } from '@/contexts/QuoteContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const FurnaceEfficiency: React.FC = () => {
  const { quoteData, updateQuoteData, setCurrentStep } = useQuote();
  
  const efficiencyOptions = [
    { 
      id: '80', 
      label: '80%',
      description: 'This is the most common type of gas furnace sold across Florida'
    },
    { 
      id: '90', 
      label: '90%+',
      description: 'Higher Efficiency - Lower Energy Costs. Not as common due to higher upfront costs.'
    }
  ];

  const handleEfficiencySelect = (efficiency: string) => {
    updateQuoteData({ furnaceEfficiency: efficiency });
    setCurrentStep('gas-type');
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-1 sm:px-2">
      <Card className="w-full">
        <CardHeader className="pb-2 sm:pb-4">
          <CardTitle className="text-center text-base sm:text-xl md:text-2xl px-1">
            Furnace Efficiency
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 sm:space-y-4 px-2 sm:px-4">
          <div className="grid gap-2 sm:gap-3">
            {efficiencyOptions.map((option) => (
              <Button
                key={option.id}
                variant="outline"
                className={`h-auto min-h-16 sm:min-h-20 text-left justify-start text-xs sm:text-sm px-3 py-3 flex flex-col items-start gap-1 ${
                  quoteData.furnaceEfficiency === option.id 
                    ? 'bg-green-500 text-white border-green-500 hover:bg-green-600' 
                    : ''
                }`}
                onClick={() => handleEfficiencySelect(option.id)}
              >
                <span className="font-medium text-sm sm:text-base">{option.label}</span>
                <span className="text-xs sm:text-sm opacity-80 leading-relaxed">
                  {option.description}
                </span>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default FurnaceEfficiency;
import React from 'react';
import { useQuote } from '@/contexts/QuoteContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const StepTwoD: React.FC = () => {
  const { quoteData, updateQuoteData, setCurrentStep } = useQuote();
  
  const packageUnits = [
    { id: '2-ton', label: '2 Ton', subLabel: '800-1000 sq.ft.' },
    { id: '2.5-ton', label: '2.5 Ton', subLabel: '1000-1300 sq.ft.' },
    { id: '3-ton', label: '3 Ton', subLabel: '1300-1600 sq.ft.' },
    { id: '3.5-ton', label: '3.5 Ton', subLabel: '1600-1900 sq.ft.' },
    { id: '4-ton', label: '4 Ton', subLabel: '1900-2200 sq.ft.' },
    { id: '5-ton', label: '5 Ton', subLabel: '2200-2600 sq.ft.' }
  ];

  const handlePackageUnitSelect = (unitId: string) => {
    const selectedUnit = packageUnits.find(unit => unit.id === unitId);
    updateQuoteData({ 
      packageUnit: unitId,
      packageUnitLabel: selectedUnit?.label,
      packageUnitSubLabel: selectedUnit?.subLabel
    });
  };

  const handleNext = () => {
    if (quoteData.packageUnit) {
      setCurrentStep(3);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-1 sm:px-2">
      <Card className="w-full">
        <CardHeader className="pb-2 sm:pb-4">
          <CardTitle className="text-center text-base sm:text-xl md:text-2xl px-1">
            Step 2: Package Unit Details
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 sm:space-y-4 px-2 sm:px-4">
          <div className="space-y-3 sm:space-y-4">
            <p className="text-center text-xs sm:text-sm md:text-base text-gray-600 px-1">
              Select package unit size
            </p>
            <p className="text-center text-xs sm:text-sm text-gray-500 px-1 italic">
              These sizes are appropriate for new mobile homes. Older mobile homes should choose 1 size larger for better heat control at peak times.
            </p>
            <div className="grid gap-2 sm:gap-3">
              {packageUnits.map((unit) => (
                <Button
                  key={unit.id}
                  variant="outline"
                  className={`h-12 sm:h-14 md:h-16 text-left justify-start text-xs sm:text-sm px-3 sm:px-4 ${
                    quoteData.packageUnit === unit.id 
                      ? 'bg-green-500 text-white border-green-500 hover:bg-green-600' 
                      : ''
                  }`}
                  onClick={() => handlePackageUnitSelect(unit.id)}
                >
                  <div className="flex flex-col items-start">
                    <span className="font-medium text-sm sm:text-base">{unit.label}</span>
                    <span className="text-xs opacity-75">{unit.subLabel}</span>
                  </div>
                </Button>
              ))}
            </div>
          </div>
          
          {quoteData.packageUnit && (
            <div className="flex justify-center pt-4 border-t">
              <Button
                onClick={handleNext}
                className="bg-green-800 hover:bg-green-900 text-white px-6 py-2 text-sm sm:text-base"
              >
                Next
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default StepTwoD;
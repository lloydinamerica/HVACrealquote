import React from 'react';
import { useQuote } from '@/contexts/QuoteContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const StepTwoB: React.FC = () => {
  const { quoteData, updateQuoteData, setCurrentStep } = useQuote();
  
  const coolingUnitSizes = [
    { id: '2-ton', label: '2 Ton', sub: '800-1200 sq. ft.' },
    { id: '2.5-ton', label: '2.5 Ton', sub: '1200-1500 sq. ft.' },
    { id: '3-ton', label: '3 Ton', sub: '1500-1800 sq. ft.' },
    { id: '3.5-ton', label: '3.5 Ton', sub: '1800-2100 sq. ft.' },
    { id: '4-ton', label: '4 Ton', sub: '2100-2400 sq. ft.' },
    { id: '5-ton', label: '5 Ton', sub: '2400-3000 sq. ft.' }
  ];

  const efficiencyLevels = [
    { id: '80%', label: '80%', sub: 'Most common type of gas furnace sold across Florida' },
    { id: '90%', label: '90%', sub: 'Higher Efficiency / Lower Energy Costs' }
  ];

  const gasTypes = ['Natural Gas', 'LP Gas'];
  const standOptions = ['Yes', 'No'];

  const handleSizeSelect = (size: string) => {
    updateQuoteData({ systemDetails: size });
  };

  const handleEfficiencySelect = (efficiency: string) => {
    updateQuoteData({ furnaceEfficiency: efficiency });
  };

  const handleGasTypeSelect = (gasType: string) => {
    updateQuoteData({ gasType: gasType });
  };

  const handleStandSelect = (standOption: string) => {
    updateQuoteData({ standRebuilt: standOption });
  };

  const handleNext = () => {
    if (quoteData.systemDetails && quoteData.furnaceEfficiency && quoteData.gasType && quoteData.standRebuilt) {
      setCurrentStep(3);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-1 sm:px-2">
      <Card className="w-full">
        <CardHeader className="pb-2 sm:pb-4">
          <CardTitle className="text-center text-base sm:text-xl md:text-2xl px-1">
            Step 2: Gas Furnace System Details
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 sm:space-y-4 px-2 sm:px-4">
          <div className="space-y-2 sm:space-y-3">
            <p className="text-center text-xs sm:text-sm md:text-base text-gray-600 font-medium px-1">
              Size of Cooling Unit:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 sm:gap-2">
              {coolingUnitSizes.map((size) => (
                <Button
                  key={size.id}
                  variant="outline"
                  className={`h-10 sm:h-12 text-left justify-start flex-col items-start p-1 sm:p-2 text-xs sm:text-sm ${
                    quoteData.systemDetails === size.id 
                      ? 'bg-green-500 text-white border-green-500 hover:bg-green-600' 
                      : ''
                  }`}
                  onClick={() => handleSizeSelect(size.id)}
                >
                  <span className="font-medium">{size.label}</span>
                  <span className="text-xs opacity-75 leading-tight">{size.sub}</span>
                </Button>
              ))}
            </div>
          </div>
          
          <div className="space-y-2 sm:space-y-3">
            <p className="text-center text-xs sm:text-sm md:text-base text-gray-600 font-medium px-1">
              Furnace Efficiency Level:
            </p>
            <div className="grid gap-1 sm:gap-2">
              {efficiencyLevels.map((efficiency) => (
                <Button
                  key={efficiency.id}
                  variant="outline"
                  className={`h-auto min-h-10 sm:min-h-12 text-left justify-start flex-col items-start p-1 sm:p-2 text-xs sm:text-sm ${
                    quoteData.furnaceEfficiency === efficiency.id 
                      ? 'bg-green-500 text-white border-green-500 hover:bg-green-600' 
                      : ''
                  }`}
                  onClick={() => handleEfficiencySelect(efficiency.id)}
                >
                  <span className="font-medium">{efficiency.label}</span>
                  <span className="text-xs opacity-75 leading-tight break-words">{efficiency.sub}</span>
                </Button>
              ))}
            </div>
          </div>

          <div className="space-y-2 sm:space-y-3">
            <p className="text-center text-xs sm:text-sm md:text-base text-gray-600 font-medium px-1">
              Type of Gas Used:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 sm:gap-2">
              {gasTypes.map((gasType) => (
                <Button
                  key={gasType}
                  variant="outline"
                  className={`h-8 sm:h-10 text-left justify-start p-1 sm:p-2 text-xs sm:text-sm ${
                    quoteData.gasType === gasType 
                      ? 'bg-green-500 text-white border-green-500 hover:bg-green-600' 
                      : ''
                  }`}
                  onClick={() => handleGasTypeSelect(gasType)}
                >
                  {gasType}
                </Button>
              ))}
            </div>
          </div>

          <div className="space-y-2 sm:space-y-3">
            <p className="text-center text-xs sm:text-sm md:text-base text-gray-600 font-medium px-1">
              Do You need the stand rebuilt?
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 sm:gap-2">
              {standOptions.map((standOption) => (
                <Button
                  key={standOption}
                  variant="outline"
                  className={`h-8 sm:h-10 text-left justify-start p-1 sm:p-2 text-xs sm:text-sm ${
                    quoteData.standRebuilt === standOption 
                      ? 'bg-green-500 text-white border-green-500 hover:bg-green-600' 
                      : ''
                  }`}
                  onClick={() => handleStandSelect(standOption)}
                >
                  {standOption}
                </Button>
              ))}
            </div>
          </div>

          {quoteData.systemDetails && quoteData.furnaceEfficiency && quoteData.gasType && quoteData.standRebuilt && (
            <div className="flex justify-center pt-2 sm:pt-4">
              <Button 
                onClick={handleNext} 
                className="px-4 sm:px-6 text-xs sm:text-sm bg-green-800 hover:bg-green-900 text-white"
              >
                Next
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default StepTwoB;
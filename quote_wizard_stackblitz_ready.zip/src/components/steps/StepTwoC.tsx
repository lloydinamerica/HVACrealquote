import React from 'react';
import { useQuote } from '@/contexts/QuoteContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const StepTwoC: React.FC = () => {
  const { quoteData, updateQuoteData, setCurrentStep } = useQuote();
  
  const unitSizes = [
    { btu: '9,000 btu', sqft: '450 sq. ft.' },
    { btu: '12,000 btu', sqft: '600 sq. ft.' },
    { btu: '15,000 btu', sqft: '750 sq. ft.' },
    { btu: '18,000 btu', sqft: '900 sq. ft.' },
    { btu: '24,000 btu', sqft: '1200 sq. ft.' },
    { btu: '30,000 btu', sqft: '1500 sq. ft.' },
    { btu: '36,000 btu', sqft: '1800 sq. ft.' },
    { btu: '48,000 btu', sqft: '2400 sq. ft.' },
    { btu: '60,000 btu', sqft: '3000 sq. ft.' }
  ];

  const zones = ['1 Zone', '2 Zones', '3 Zones', '4 Zones'];

  const handleUnitSizeSelect = (size: string) => {
    updateQuoteData({ systemDetails: size });
  };

  const handleZoneSelect = (zone: string) => {
    updateQuoteData({ systemSubDetails: zone });
  };

  const canProceed = quoteData.systemDetails && quoteData.systemSubDetails;

  const handleNext = () => {
    if (canProceed) {
      setCurrentStep(3);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-1 sm:px-2">
      <Card className="w-full">
        <CardHeader className="pb-2 sm:pb-4">
          <CardTitle className="text-center text-base sm:text-xl md:text-2xl px-1">
            Step 3: Ductless Mini-Split Details
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 sm:space-y-6 px-2 sm:px-4">
          {/* Area 1: Size of Unit */}
          <div className="space-y-3">
            <h3 className="text-sm sm:text-base md:text-lg font-medium text-center">
              Size of Unit
            </h3>
            <div className="grid gap-1 sm:gap-2">
              {unitSizes.map((unit, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className={`h-10 sm:h-12 text-left justify-start text-xs sm:text-sm px-2 ${
                    quoteData.systemDetails === `${unit.btu} - ${unit.sqft}` 
                      ? 'bg-green-500 text-white border-green-500 hover:bg-green-600' 
                      : ''
                  }`}
                  onClick={() => handleUnitSizeSelect(`${unit.btu} - ${unit.sqft}`)}
                >
                  <div className="flex flex-col">
                    <span className="font-medium">{unit.btu}</span>
                    <span className="text-xs opacity-75">{unit.sqft}</span>
                  </div>
                </Button>
              ))}
            </div>
          </div>

          {/* Area 2: Number of Zones */}
          <div className="space-y-3 border-t pt-4">
            <h3 className="text-sm sm:text-base md:text-lg font-medium text-center">
              Number of Zones (Indoor Units)
            </h3>
            <div className="grid gap-1 sm:gap-2">
              {zones.map((zone) => (
                <Button
                  key={zone}
                  variant="outline"
                  className={`h-10 sm:h-12 text-xs sm:text-sm px-2 ${
                    quoteData.systemSubDetails === zone 
                      ? 'bg-green-500 text-white border-green-500 hover:bg-green-600' 
                      : ''
                  }`}
                  onClick={() => handleZoneSelect(zone)}
                >
                  {zone}
                </Button>
              ))}
            </div>
          </div>

          {/* Next Button */}
          {canProceed && (
            <div className="flex justify-center pt-4 border-t">
              <Button
                onClick={handleNext}
                className="bg-green-800 hover:bg-green-900 text-white px-6 py-2 text-sm sm:text-base"
              >
                Next
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default StepTwoC;
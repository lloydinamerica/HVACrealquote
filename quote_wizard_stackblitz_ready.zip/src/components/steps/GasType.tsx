import React from 'react';
import { useQuote } from '@/contexts/QuoteContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const GasType: React.FC = () => {
  const { quoteData, updateQuoteData, setCurrentStep } = useQuote();
  
  const gasTypes = [
    { id: 'natural', label: 'Natural Gas' },
    { id: 'lp', label: 'LP Gas' }
  ];

  const handleGasTypeSelect = (gasType: string) => {
    updateQuoteData({ gasType });
  };

  const handleFurnaceStandSelect = (needsRebuilt: string) => {
    updateQuoteData({ furnaceStandRebuilt: needsRebuilt });
    setCurrentStep(3); // Go to Customer Information
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-1 sm:px-2">
      <Card className="w-full">
        <CardHeader className="pb-2 sm:pb-4">
          <CardTitle className="text-center text-base sm:text-xl md:text-2xl px-1">
            Type of Gas Used
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 sm:space-y-4 px-2 sm:px-4">
          <div className="grid gap-2 sm:gap-3">
            {gasTypes.map((type) => (
              <Button
                key={type.id}
                variant="outline"
                className={`h-12 sm:h-14 md:h-16 text-center justify-center text-sm sm:text-base px-3 ${
                  quoteData.gasType === type.id 
                    ? 'bg-green-500 text-white border-green-500 hover:bg-green-600' 
                    : ''
                }`}
                onClick={() => handleGasTypeSelect(type.id)}
              >
                {type.label}
              </Button>
            ))}
          </div>
          
          {quoteData.gasType && (
            <div className="border-t pt-3 sm:pt-4">
              <h3 className="text-xs sm:text-sm md:text-base font-medium mb-3 sm:mb-4 text-center px-1">
                Do You Need the Furnace Stand Rebuilt?
              </h3>
              <div className="grid gap-2 sm:gap-3">
                <Button
                  variant="outline"
                  className={`h-12 sm:h-14 md:h-16 text-center justify-center text-sm sm:text-base px-3 ${
                    quoteData.furnaceStandRebuilt === 'yes' 
                      ? 'bg-green-500 text-white border-green-500 hover:bg-green-600' 
                      : ''
                  }`}
                  onClick={() => handleFurnaceStandSelect('yes')}
                >
                  Yes
                </Button>
                <Button
                  variant="outline"
                  className={`h-12 sm:h-14 md:h-16 text-center justify-center text-sm sm:text-base px-3 ${
                    quoteData.furnaceStandRebuilt === 'no' 
                      ? 'bg-green-500 text-white border-green-500 hover:bg-green-600' 
                      : ''
                  }`}
                  onClick={() => handleFurnaceStandSelect('no')}
                >
                  No
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default GasType;
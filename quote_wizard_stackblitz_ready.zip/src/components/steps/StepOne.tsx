import React from 'react';
import { useQuote } from '@/contexts/QuoteContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FinancingSection } from '@/components/FinancingSection';

const StepOne: React.FC = () => {
  const { quoteData, updateQuoteData, setCurrentStep } = useQuote();
  
  const systemTypes = [
    { 
      id: 'heating-cooling', 
      label: 'Heating & Cooling',
      icon: 'https://d64gsuwffb70l.cloudfront.net/682fec4a23651177574ccb93_1747983058696_7ea55613.jpg'
    },
    { 
      id: 'heating-only', 
      label: 'Heating Only',
      icon: 'https://d64gsuwffb70l.cloudfront.net/682fec4a23651177574ccb93_1747983058935_1edb012e.jpg'
    }
  ];

  const subTypes = {
    'heating-cooling': [
      { name: 'Split System Heat Pump', image: 'https://d64gsuwffb70l.cloudfront.net/682fec4a23651177574ccb93_1748033697205_b6022f54.jpg' },
      { name: 'Gas Furnace System', image: 'https://d64gsuwffb70l.cloudfront.net/682fec4a23651177574ccb93_1748033741173_03e0d210.jpg' },
      { name: 'Ductless Mini-Split', image: 'https://d64gsuwffb70l.cloudfront.net/682fec4a23651177574ccb93_1748033764918_5b3fb661.jpg' },
      { name: 'Package Unit', image: 'https://d64gsuwffb70l.cloudfront.net/682fec4a23651177574ccb93_1748033786833_844ecaba.jpg' }
    ],
    'heating-only': [
      { name: 'Gas Furnace', image: 'https://d64gsuwffb70l.cloudfront.net/682fec4a23651177574ccb93_1748038005998_88e3063f.jpg' }
    ]
  };

  const handleSystemTypeSelect = (type: string) => {
    updateQuoteData({ systemType: type, systemSubType: undefined });
  };

  const handleSubTypeSelect = (subType: string) => {
    updateQuoteData({ systemSubType: subType });
    
    if (quoteData.systemType === 'heating-only' && subType === 'Gas Furnace') {
      setCurrentStep('gas-furnace-size');
      return;
    }
    
    if (subType === 'Package Unit') {
      setCurrentStep('2d');
    } else if (subType === 'Split System Heat Pump') {
      setCurrentStep('2a');
    } else {
      setCurrentStep(2);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-1 sm:px-2">
      <Card className="w-full">
        <CardHeader className="pb-2 sm:pb-4">
          <CardTitle className="text-center text-base sm:text-xl md:text-2xl px-1">
            Select System Type
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 sm:space-y-4 px-2 sm:px-4">
          {!quoteData.systemType ? (
            <div className="space-y-3 sm:space-y-4">
              <div className="grid gap-2 sm:gap-3">
                {systemTypes.map((type) => (
                  <Button
                    key={type.id}
                    variant="outline"
                    className={`h-20 sm:h-24 md:h-28 text-xs sm:text-sm md:text-base px-2 sm:px-4 flex flex-col items-center justify-center gap-2 ${
                      quoteData.systemType === type.id 
                        ? 'bg-green-500 text-white border-green-500 hover:bg-green-600' 
                        : ''
                    }`}
                    onClick={() => handleSystemTypeSelect(type.id)}
                  >
                    <img 
                      src={type.icon} 
                      alt={type.label}
                      className="w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 object-contain"
                    />
                    <span className="text-center break-words">{type.label}</span>
                  </Button>
                ))}
              </div>
              <FinancingSection />
            </div>
          ) : (
            <div className="space-y-3 sm:space-y-4">
              <p className="text-center text-xs sm:text-sm md:text-base px-1 break-words">
                Selected: {systemTypes.find(t => t.id === quoteData.systemType)?.label}
              </p>
              <div className="border-t pt-3 sm:pt-4">
                <h3 className="text-xs sm:text-sm md:text-base font-medium mb-3 sm:mb-4 text-center px-1">
                  Choose Sub-Type:
                </h3>
                <div className="grid gap-2 sm:gap-3">
                  {subTypes[quoteData.systemType as keyof typeof subTypes]?.map((subType) => (
                    <Button
                      key={subType.name}
                      variant="outline"
                      className={`h-auto min-h-16 sm:min-h-20 text-xs sm:text-sm px-2 sm:px-3 py-2 flex flex-col items-center gap-2 ${
                        quoteData.systemSubType === subType.name 
                          ? 'bg-green-500 text-white border-green-500 hover:bg-green-600' 
                          : ''
                      }`}
                      onClick={() => handleSubTypeSelect(subType.name)}
                    >
                      {subType.image && (
                        <img 
                          src={subType.image} 
                          alt={subType.name}
                          className="w-12 h-12 sm:w-16 sm:h-16 object-contain"
                        />
                      )}
                      <span className="text-center break-words leading-tight">{subType.name}</span>
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default StepOne;
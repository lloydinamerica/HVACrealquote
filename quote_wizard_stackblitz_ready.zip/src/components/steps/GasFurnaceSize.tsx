import React from 'react';
import { useQuote } from '@/contexts/QuoteContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const GasFurnaceSize: React.FC = () => {
  const { quoteData, updateQuoteData, setCurrentStep } = useQuote();
  
  const homeSizes = [
    { id: 'basic', label: '800-1200 sq.ft.' },
    { id: 'standard', label: '1200-1500 sq. ft.' },
    { id: 'premium', label: '1500-1800 sq. ft.' },
    { id: 'deluxe', label: '1800-2100 sq. ft.' },
    { id: 'custom', label: '2100-2400 sq. ft.' },
    { id: 'emergency', label: '2400-3000 sq.ft.' }
  ];

  const handleHomeSizeSelect = (size: string) => {
    updateQuoteData({ homeSize: size });
    setCurrentStep('furnace-efficiency');
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-1 sm:px-2">
      <Card className="w-full">
        <CardHeader className="pb-2 sm:pb-4">
          <CardTitle className="text-center text-base sm:text-xl md:text-2xl px-1">
            System Details
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 sm:space-y-4 px-2 sm:px-4">
          <div className="space-y-3 sm:space-y-4">
            <p className="text-center text-xs sm:text-sm md:text-base text-gray-600 px-1">
              Choose home size:
            </p>
            <div className="grid gap-1 sm:gap-2">
              {homeSizes.map((size) => (
                <Button
                  key={size.id}
                  variant="outline"
                  className={`h-10 sm:h-12 md:h-14 text-left justify-start text-xs sm:text-sm px-2 break-words ${
                    quoteData.homeSize === size.id 
                      ? 'bg-green-500 text-white border-green-500 hover:bg-green-600' 
                      : ''
                  }`}
                  onClick={() => handleHomeSizeSelect(size.id)}
                >
                  <span className="truncate">{size.label}</span>
                </Button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default GasFurnaceSize;
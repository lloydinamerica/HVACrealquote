import React from 'react';
import { useQuote } from '@/contexts/QuoteContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import StepTwoA from './StepTwoA';
import StepTwoB from './StepTwoB';
import StepTwoC from './StepTwoC';

const StepTwo: React.FC = () => {
  const { quoteData, updateQuoteData, setCurrentStep } = useQuote();
  
  if (quoteData.systemSubType === 'Gas Furnace System') {
    return <StepTwoB />;
  }
  
  if (quoteData.systemSubType === 'Ductless Mini-Split') {
    return <StepTwoC />;
  }
  
  const systemDetails = [
    { id: 'a', label: 'Basic Installation' },
    { id: 'b', label: 'Standard Installation' },
    { id: 'c', label: 'Premium Installation' },
    { id: 'd', label: 'Deluxe Installation' },
    { id: 'e', label: 'Custom Installation' },
    { id: 'f', label: 'Emergency Installation' }
  ];

  const subDetails = [
    'Single Zone',
    'Multi Zone',
    'Smart Controls',
    'Energy Efficient',
    'High Performance'
  ];

  const standOptions = ['Yes', 'No'];

  const handleDetailSelect = (detail: string) => {
    updateQuoteData({ systemDetails: detail, systemSubDetails: undefined });
  };

  const handleSubDetailSelect = (subDetail: string) => {
    updateQuoteData({ systemSubDetails: subDetail, sectionTwoOption: quoteData.systemDetails });
  };

  const handleStandSelect = (standOption: string) => {
    updateQuoteData({ standReplaced: standOption });
  };

  const handleNext = () => {
    if (quoteData.systemDetails && quoteData.systemSubDetails && quoteData.standReplaced) {
      setCurrentStep(3);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-1 sm:px-2">
      <Card className="w-full">
        <CardHeader className="pb-2 sm:pb-4">
          <CardTitle className="text-center text-base sm:text-xl md:text-2xl px-1">
            Step 2: Split System Heat Pump Details
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 sm:space-y-4 px-2 sm:px-4">
          {!quoteData.systemDetails ? (
            <div className="space-y-3 sm:space-y-4">
              <p className="text-center text-xs sm:text-sm md:text-base text-gray-600 px-1">
                Choose installation type:
              </p>
              <div className="grid gap-1 sm:gap-2">
                {systemDetails.map((detail) => (
                  <Button
                    key={detail.id}
                    variant="outline"
                    className={`h-10 sm:h-12 md:h-14 text-left justify-start text-xs sm:text-sm px-2 break-words ${
                      quoteData.systemDetails === detail.id 
                        ? 'bg-green-500 text-white border-green-500 hover:bg-green-600' 
                        : ''
                    }`}
                    onClick={() => handleDetailSelect(detail.id)}
                  >
                    <span className="font-medium mr-1">{detail.id.toUpperCase()}.</span>
                    <span className="truncate">{detail.label}</span>
                  </Button>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-3 sm:space-y-4">
              <p className="text-center text-xs sm:text-sm md:text-base px-1 break-words">
                Selected: {systemDetails.find(d => d.id === quoteData.systemDetails)?.label}
              </p>
              <div className="border-t pt-3 sm:pt-4">
                <h3 className="text-xs sm:text-sm md:text-base font-medium mb-3 sm:mb-4 text-center px-1">
                  Choose Configuration:
                </h3>
                <div className="grid gap-1 sm:gap-2">
                  {subDetails.map((subDetail) => (
                    <Button
                      key={subDetail}
                      variant="outline"
                      className={`h-8 sm:h-10 md:h-12 text-xs sm:text-sm px-2 break-words ${
                        quoteData.systemSubDetails === subDetail 
                          ? 'bg-green-500 text-white border-green-500 hover:bg-green-600' 
                          : ''
                      }`}
                      onClick={() => handleSubDetailSelect(subDetail)}
                    >
                      <span className="truncate">{subDetail}</span>
                    </Button>
                  ))}
                </div>
              </div>
              
              {quoteData.systemSubDetails && (
                <div className="border-t pt-3 sm:pt-4">
                  <h3 className="text-xs sm:text-sm md:text-base font-medium mb-3 sm:mb-4 text-center px-1">
                    Do You need the stand replaced?
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 sm:gap-2">
                    {standOptions.map((standOption) => (
                      <Button
                        key={standOption}
                        variant="outline"
                        className={`h-8 sm:h-10 text-left justify-start p-1 sm:p-2 text-xs sm:text-sm ${
                          quoteData.standReplaced === standOption 
                            ? 'bg-green-500 text-white border-green-500 hover:bg-green-600' 
                            : ''
                        }`}
                        onClick={() => handleStandSelect(standOption)}
                      >
                        {standOption}
                      </Button>
                    ))}
                  </div>
                </div>
              )}
              
              {quoteData.systemSubDetails && quoteData.standReplaced && (
                <div className="flex justify-center pt-4 border-t">
                  <Button
                    onClick={handleNext}
                    className="bg-green-800 hover:bg-green-900 text-white px-6 py-2 text-sm sm:text-base"
                  >
                    Next
                  </Button>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default StepTwo;
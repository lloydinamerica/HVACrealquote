import React, { createContext, useContext, useState } from 'react';

interface QuoteData {
  systemType?: string;
  systemSubType?: string;
  systemDetails?: string;
  systemSubDetails?: string;
  sectionTwoOption?: string;
  packageUnit?: string;
  packageUnitLabel?: string;
  packageUnitSubLabel?: string;
  tonnage?: string;
  airHandlerLocation?: string;
  homeSize?: string;
  furnaceEfficiency?: string;
  gasType?: string;
  standReplaced?: string;
  standRebuilt?: string;
  furnaceStandRebuilt?: string;
  fullName?: string;
  email?: string;
  phone?: string;
  address?: string;
  city?: string;
  zipCode?: string;
}

interface QuoteContextType {
  currentStep: number | string;
  quoteData: QuoteData;
  setCurrentStep: (step: number | string) => void;
  updateQuoteData: (data: Partial<QuoteData>) => void;
  calculatePrice: () => number;
}

const QuoteContext = createContext<QuoteContextType | undefined>(undefined);

export const useQuote = () => {
  const context = useContext(QuoteContext);
  if (!context) {
    throw new Error('useQuote must be used within QuoteProvider');
  }
  return context;
};

export const QuoteProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentStep, setCurrentStep] = useState<number | string>(1);
  const [quoteData, setQuoteData] = useState<QuoteData>({});

  const updateQuoteData = (data: Partial<QuoteData>) => {
    setQuoteData(prev => ({ ...prev, ...data }));
  };

  const calculatePrice = () => {
    let basePrice = 1000;
    if (quoteData.systemType === 'residential') basePrice += 500;
    if (quoteData.systemType === 'commercial') basePrice += 1500;
    if (quoteData.systemSubType) basePrice += 300;
    if (quoteData.systemDetails) basePrice += 200;
    return basePrice;
  };

  return (
    <QuoteContext.Provider value={{
      currentStep,
      quoteData,
      setCurrentStep,
      updateQuoteData,
      calculatePrice
    }}>
      {children}
    </QuoteContext.Provider>
  );
};